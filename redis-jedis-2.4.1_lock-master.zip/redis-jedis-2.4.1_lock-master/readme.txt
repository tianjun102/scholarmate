<dependency>
  <groupId>com.github.jedis-lock</groupId>
  <artifactId>jedis-lock</artifactId>
  <version>1.0.0</version>
</dependency>
<dependency>
  <groupId>redis.clients</groupId>
  <artifactId>jedis</artifactId>
  <version>2.4.1</version>
</dependency>
<dependency>
  <groupId>org.apache.commons</groupId>
  <artifactId>commons-pool2</artifactId>
  <version>2.1</version>
</dependency>

redis中文网
http://redis.cn/

jedis下载地址
https://github.com/xetorthio/jedis

入门手册
http://wenku.baidu.com/view/adbc935ebe23482fb4da4c6d.html