package com.yaoguoyin.redis.test;

import org.springframework.data.redis.connection.RedisConnection;

public class Hello {

	public static void main(String[] args) {
//		RedisConnection
	}

}
