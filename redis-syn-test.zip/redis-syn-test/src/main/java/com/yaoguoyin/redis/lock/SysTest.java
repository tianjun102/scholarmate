package com.yaoguoyin.redis.lock;

import org.springframework.stereotype.Component;

@Component
public class SysTest {
	private static int i = 0;

	@P4jSyn(synKey = "12345")
	public void add(@P4jSynKey(index = 1) String key, @P4jSynKey(index = 0) int key1) {
		i = i + 1;
		System.out.println("i=-===========" + i);
	}
}
