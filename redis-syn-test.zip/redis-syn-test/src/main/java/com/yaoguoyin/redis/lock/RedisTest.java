package com.yaoguoyin.redis.lock;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.yaoguoyin.redis.BaseTest;

public class RedisTest extends BaseTest {
	@Autowired
	private SysTest sysTest;

	@Test
	public void testHello() throws InterruptedException {
		for (int i = 0; i < 100; i++) {
			new Thread(new Runnable() {

				@Override
				public void run() {
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					sysTest.add("xxxxx", 111111);
				}
			}).start();
		}

		TimeUnit.SECONDS.sleep(20);
	}
	
	@Test
	public void testHello2() throws InterruptedException{
		sysTest.add("xxxxx", 111111);
		TimeUnit.SECONDS.sleep(10);
	}
}
